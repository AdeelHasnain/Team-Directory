# Team Directory - Module Explanation

Brief overview of each module and how they work together.

---

## 📁 Database Layer

### `mysql/employees.sql`
**Purpose:** Database schema and seed data

- Creates `team_directory` database
- Creates `Employees` table with columns:
  - `ID` (Primary Key, Auto Increment)
  - `FirstName` (VARCHAR)
  - `LastName` (VARCHAR)
  - `Role` (VARCHAR)
- Inserts 5 sample employee records
- **Run once:** `mysql -u root -p < mysql/employees.sql`

---

## 🔧 Backend (ColdFusion)

### `Application.cfc`
**Purpose:** Application configuration and initialization

- Sets application name: `TeamDirectory`
- Disables session management (not needed for REST API)
- **Initializes:** `application.dsn = "team_directory"` on app start
- **Note:** DSN must exist in ColdFusion Administrator

**Key Function:**
- `onApplicationStart()` - Runs once when app starts, sets the datasource name

---

### `api/Employees.cfc`
**Purpose:** Data access layer (business logic)

- **Component:** ColdFusion Component (CFC) for data operations
- **Method:** `get(search = "")`
  - Queries MySQL database using `application.dsn`
  - **Security:** Uses `<cfqueryparam>` for all user inputs (SQL injection protection)
  - **Optional search:** If `search` parameter provided, filters by `FirstName` or `LastName` using `LIKE`
  - **Returns:** Array of structs with camelCase keys: `{id, firstName, lastName, role}`

**Flow:**
1. Accepts optional `search` argument
2. Builds SQL query (with or without WHERE clause)
3. Executes query with `cfqueryparam` protection
4. Loops through results, builds array of structs
5. Returns array (will be serialized to JSON by endpoint)

---

### `api/employees.cfm`
**Purpose:** REST API endpoint (HTTP handler)

- **URL:** `GET /api/employees.cfm`
- **Handles:**
  - CORS headers (allows React to fetch from different origin)
  - OPTIONS preflight requests (CORS)
  - GET requests only (returns 405 for other methods)
  - Error handling (try/catch, returns 500 with JSON error)

**Flow:**
1. Sets CORS headers (`Access-Control-Allow-Origin: *`)
2. Handles OPTIONS preflight → returns 204
3. Validates method → GET only, else 405
4. Creates `Employees.cfc` instance
5. Extracts optional `?search=` from URL
6. Calls `Employees.get(search)`
7. Serializes result to JSON
8. Returns 200 with JSON or 500 with error JSON

**Response Format:**
```json
[
  {"id": 1, "firstName": "Sarah", "lastName": "Johnson", "role": "Software Engineer"},
  ...
]
```

---

## ⚛️ Frontend (React)

### `src/App.jsx`
**Purpose:** Main React component (UI and state management)

**State (useState):**
- `employees` - Array of all employees from API
- `loading` - Boolean, true while fetching
- `error` - String, error message if fetch fails
- `search` - String, search input value

**Effects (useEffect):**
- On mount: Fetches employees from ColdFusion API
- Uses `fetch()` to call `/api/employees.cfm`
- Handles loading, success, and error states
- Cleanup: Cancels request if component unmounts

**Client-Side Filtering:**
- `filtered` - Computed array filtered by `search` value
- Case-insensitive match on `firstName` or `lastName`
- Updates in real-time as user types

**UI Rendering:**
- Search bar with clear button
- Stats bar (total/found count)
- Loading spinner
- Error state with retry button
- Empty state (no results)
- **Desktop:** Table view with avatars
- **Tablet/Mobile:** Card grid layout
- Footer with employee count

**Helper Function:**
- `getAvatarColor(name)` - Generates gradient color for avatar based on name

---

### `src/App.css`
**Purpose:** Styling and responsive design

- **Design:** Modern, premium UI with glassmorphism effects
- **Colors:** Gradient backgrounds, neutral cards, professional palette
- **Animations:** Fade-in, slide-in, hover effects
- **Responsive:**
  - Desktop (1025px+): Table view
  - Tablet (769-1024px): 2-column card grid
  - Mobile (≤768px): Single-column cards
- **Features:** Smooth transitions, backdrop blur, shadows

---

### `src/index.css`
**Purpose:** Base/reset styles

- CSS reset (box-sizing, margins)
- Font family setup
- Smooth scrolling
- Base body styles

---

## 🔄 Data Flow

```
1. User opens React app
   ↓
2. App.jsx useEffect runs → fetch('/api/employees.cfm')
   ↓
3. employees.cfm receives GET request
   ↓
4. employees.cfm creates Employees.cfc instance
   ↓
5. Employees.cfc.get() queries MySQL via application.dsn
   ↓
6. MySQL returns rows → Employees.cfc builds array of structs
   ↓
7. employees.cfm serializes to JSON → returns to React
   ↓
8. App.jsx receives JSON → setEmployees(data)
   ↓
9. React renders table/cards
   ↓
10. User types in search → client-side filter updates display
```

---

## 🔐 Security Features

- **SQL Injection Protection:** `<cfqueryparam>` for all user inputs
- **CORS:** Proper headers for cross-origin requests
- **Method Validation:** Only GET allowed, others return 405
- **Error Handling:** Try/catch prevents stack traces from leaking

---

## 📦 File Structure Summary

```
MED49Solution/
├── mysql/
│   └── employees.sql          # Database schema + seed data
├── coldfusion/
│   ├── Application.cfc        # App config (DSN setup)
│   └── api/
│       ├── Employees.cfc      # Data access (queries DB)
│       └── employees.cfm      # REST endpoint (HTTP handler)
└── frontend/
    └── src/
        ├── App.jsx            # Main React component
        ├── App.css            # Component styles
        └── index.css          # Base styles
```

---

## 🎯 Key Design Patterns

1. **Separation of Concerns:**
   - `Employees.cfc` = Data access (business logic)
   - `employees.cfm` = HTTP handling (presentation layer)
   - `App.jsx` = UI and client-side logic

2. **Security First:**
   - All database inputs use `cfqueryparam`
   - CORS properly configured
   - Error messages don't expose internals

3. **Responsive Design:**
   - Mobile-first approach
   - Progressive enhancement
   - Graceful degradation

4. **Modern React:**
   - Functional components only
   - Hooks for state and effects
   - Cleanup in useEffect

---

## 🚀 Quick Reference

| Module | File | Purpose |
|--------|------|---------|
| Database | `mysql/employees.sql` | Schema + seed data |
| App Config | `coldfusion/Application.cfc` | DSN initialization |
| Data Access | `coldfusion/api/Employees.cfc` | Database queries |
| API Endpoint | `coldfusion/api/employees.cfm` | REST handler |
| UI Component | `frontend/src/App.jsx` | React component |
| Styles | `frontend/src/App.css` | Component styles |

---

**All modules work together to create a secure, responsive, production-ready Team Directory application.**

