import { useState, useEffect } from 'react'
import './App.css'

// API URL: set VITE_API_URL in .env or it falls back to common CF port
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8500/api/employees.cfm'

function App() {
  const [employees, setEmployees] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [search, setSearch] = useState('')

  // Fetch employees from ColdFusion API
  useEffect(() => {
    let cancelled = false

    async function fetchEmployees() {
      setLoading(true)
      setError(null)
      try {
        const res = await fetch(API_URL)
        if (!res.ok) throw new Error(`HTTP ${res.status}: ${res.statusText}`)
        const data = await res.json()
        if (!cancelled) {
          setEmployees(Array.isArray(data) ? data : [])
        }
      } catch (e) {
        if (!cancelled) {
          setError(e.message || 'Failed to load employees. Please ensure ColdFusion is running and the API is deployed.')
        }
      } finally {
        if (!cancelled) setLoading(false)
      }
    }

    fetchEmployees()
    return () => { cancelled = true }
  }, [])

  // Client-side, case-insensitive filter by firstName or lastName
  const filtered = employees.filter((e) => {
    if (!search.trim()) return true
    const q = search.trim().toLowerCase()
    const first = (e.firstName || '').toLowerCase()
    const last = (e.lastName || '').toLowerCase()
    return first.includes(q) || last.includes(q)
  })

  // Generate avatar color based on name
  const getAvatarColor = (name) => {
    const colors = [
      'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
      'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
      'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
      'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
      'linear-gradient(135deg, #30cfd0 0%, #330867 100%)',
      'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)',
      'linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%)',
    ]
    const index = (name.charCodeAt(0) || 0) % colors.length
    return colors[index]
  }

  return (
    <div className="app">
      <div className="background-pattern"></div>
      
      <header className="header">
        <div className="header-content">
          <div className="header-brand">
            <div className="brand-icon">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <circle cx="9" cy="7" r="4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <div>
              <h1>Team Directory</h1>
              <p className="subtitle">Your company's talent hub</p>
            </div>
          </div>
        </div>
      </header>

      <main className="main">
        <div className="content-wrapper">
          <div className="search-section">
            <div className="search-wrapper">
              <svg className="search-icon" width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="11" cy="11" r="8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="m21 21-4.35-4.35" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <input
                id="search"
                type="search"
                placeholder="Search by name..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="search-input"
                aria-label="Search employees by first or last name"
              />
              {search && (
                <button
                  onClick={() => setSearch('')}
                  className="search-clear"
                  aria-label="Clear search"
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <line x1="18" y1="6" x2="6" y2="18" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                    <line x1="6" y1="6" x2="18" y2="18" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                  </svg>
                </button>
              )}
            </div>
            {!loading && !error && employees.length > 0 && (
              <div className="stats-bar">
                <div className="stat-item">
                  <span className="stat-value">{employees.length}</span>
                  <span className="stat-label">Total</span>
                </div>
                {search && (
                  <div className="stat-item">
                    <span className="stat-value">{filtered.length}</span>
                    <span className="stat-label">Found</span>
                  </div>
                )}
              </div>
            )}
          </div>

          {loading && (
            <div className="loading-container">
              <div className="spinner-wrapper">
                <div className="spinner"></div>
              </div>
              <p className="loading-text">Loading team members...</p>
            </div>
          )}

          {error && (
            <div className="error-container">
              <div className="error-icon-wrapper">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2"/>
                  <line x1="12" y1="8" x2="12" y2="12" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                  <line x1="12" y1="16" x2="12.01" y2="16" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                </svg>
              </div>
              <h3>Unable to Load Data</h3>
              <p>{error}</p>
              <button onClick={() => window.location.reload()} className="retry-button">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M23 4v6h-6M1 20v-6h6M3.51 9a9 9 0 0 1 14.85-3.48L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                Try Again
              </button>
            </div>
          )}

          {!loading && !error && (
            <>
              {filtered.length === 0 ? (
                <div className="empty-state">
                  <div className="empty-icon-wrapper">
                    <svg width="64" height="64" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <circle cx="11" cy="11" r="8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      <path d="m21 21-4.35-4.35" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <h3>No Results Found</h3>
                  <p>{search ? `No employees match "${search}"` : 'No employees found.'}</p>
                  {search && (
                    <button onClick={() => setSearch('')} className="clear-search-button">
                      Clear Search
                    </button>
                  )}
                </div>
              ) : (
                <>
                  {/* Desktop: table */}
                  <div className="table-wrap">
                    <table className="employee-table">
                      <thead>
                        <tr>
                          <th>Employee</th>
                          <th>Role</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filtered.map((e, idx) => (
                          <tr key={e.id} className="table-row" style={{ animationDelay: `${idx * 0.03}s` }}>
                            <td>
                              <div className="employee-info">
                                <div 
                                  className="employee-avatar"
                                  style={{ background: getAvatarColor(e.firstName + e.lastName) }}
                                >
                                  {e.firstName?.[0]}{e.lastName?.[0]}
                                </div>
                                <div className="employee-details">
                                  <div className="employee-name">{e.firstName} {e.lastName}</div>
                                </div>
                              </div>
                            </td>
                            <td>
                              <span className="role-badge">{e.role}</span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Tablet / mobile: card grid */}
                  <div className="card-grid">
                    {filtered.map((e, idx) => (
                      <article 
                        key={e.id} 
                        className="employee-card" 
                        style={{ animationDelay: `${idx * 0.03}s` }}
                      >
                        <div 
                          className="card-avatar"
                          style={{ background: getAvatarColor(e.firstName + e.lastName) }}
                        >
                          {e.firstName?.[0]}{e.lastName?.[0]}
                        </div>
                        <div className="card-content">
                          <h3 className="card-name">{e.firstName} {e.lastName}</h3>
                          <p className="card-role">{e.role}</p>
                        </div>
                        <div className="card-decoration"></div>
                      </article>
                    ))}
                  </div>
                </>
              )}
            </>
          )}
        </div>
      </main>

      <footer className="footer">
        <p>Team Directory &middot; Powered by ColdFusion & React</p>
      </footer>
    </div>
  )
}

export default App
