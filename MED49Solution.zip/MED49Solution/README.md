# Team Directory

A production-ready **Team Directory** application: MySQL database, ColdFusion REST API, and a React (Vite) frontend. Employees are loaded from the API and shown in a responsive UI with client-side search.

---

## Project overview

| Layer     | Tech           | Purpose                                      |
|----------|----------------|----------------------------------------------|
| Database | MySQL          | `team_directory` DB, `Employees` table       |
| Backend  | ColdFusion     | REST endpoint `GET /api/employees.cfm`       |
| Frontend | React (Vite)   | Fetch, display, and search employees         |

**Features**

- RESTful `GET /api/employees` returning JSON
- CORS, HTTP status codes, and basic error handling
- Secure pattern: `cfqueryparam` for parameterized queries (see `config/DATASOURCE.md`)
- React: `useEffect` for API call, `useState` for list, loading, error, and search
- Responsive: table on desktop, card grid on tablet/mobile
- Case-insensitive search by first or last name (client-side)

---

## Repository structure

```
MED49Solution/
├── mysql/
│   └── employees.sql          # DB, table, seed data
├── coldfusion/
│   ├── Application.cfc        # App name, DSN in application scope
│   ├── api/
│   │   ├── Employees.cfc      # Data access: get()
│   │   └── employees.cfm      # REST endpoint, CORS, JSON
│   └── config/
│       └── DATASOURCE.md      # DSN setup and cfqueryparam notes
├── frontend/                  # Vite + React app
│   ├── src/
│   │   ├── App.jsx
│   │   ├── App.css
│   │   ├── index.css
│   │   └── main.jsx
│   ├── index.html
│   └── package.json
└── README.md                  # This file
```

---

## Quick Start

**Prerequisites:**
- MySQL 5.7+ (or 8.x)
- ColdFusion server (any version with MySQL support)
- Node.js 18+ and npm

**Quick commands:**

```bash
# 1. Setup database
mysql -u root -p < mysql/employees.sql

# 2. Deploy ColdFusion API
# Copy coldfusion/ folder contents to your CF web root
# Create DSN "team_directory" in CF Admin

# 3. Start React frontend
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173` (or your Vite port) in your browser.

---

## 1. MySQL setup

**Requirements:** MySQL 5.7+ (or 8.x).

1. Start MySQL.

2. Run the schema and seed script:

   ```bash
   mysql -u root -p < mysql/employees.sql
   ```

   Or from the MySQL client:

   ```sql
   source /path/to/MED49Solution/mysql/employees.sql
   ```

3. This will:
   - Create database `team_directory`
   - Create table `Employees` with columns: `ID` (Primary Key, Auto Increment), `FirstName`, `LastName`, `Role`
   - Insert 5 sample employee records

4. Check:

   ```sql
   USE team_directory;
   SELECT * FROM Employees;
   ```

---

## 2. ColdFusion setup

### 2.1 Deploy the API

1. Copy the contents of `coldfusion/` into your CF web root (e.g. `C:\ColdFusion2021\cfusion\wwwroot` or `{cf-home}/wwwroot`), keeping the folder structure:

   - `Application.cfc` at the root of the app
   - `api/Employees.cfc` and `api/employees.cfm` under `api/`

2. The endpoint will be:

   ```
   http://<host>:<port>/api/employees.cfm
   ```

   Typical CF port: `8500` → `http://localhost:8500/api/employees.cfm`

### 2.2 Datasource (DSN)

1. In **ColdFusion Administrator** → **Data & Services** → **Data Sources**, add:

   - **Data Source Name:** `team_directory`
   - **Driver:** MySQL
   - **Server:** `localhost` (or your DB host)
   - **Port:** `3306`
   - **Database:** `team_directory`
   - **Username / Password:** your MySQL user

2. Submit and **Verify**.

3. If you use a different DSN name, set it in `Application.cfc`:

   ```cfml
   application.dsn = "your_dsn_name";
   ```

More detail: `coldfusion/config/DATASOURCE.md`.

### 2.3 Test the API

- Browser or `curl`:

  ```bash
  curl -s http://localhost:8500/api/employees.cfm
  ```

- Expected: JSON array of employee objects, e.g.:

  ```json
  [{"id":1,"firstName":"Sarah","lastName":"Johnson","role":"Software Engineer"}, ...]
  ```

---

## 3. React (frontend) setup

### 3.1 Install and run

```bash
cd frontend
npm install
npm run dev
```

Vite will start (e.g. `http://localhost:5173`). Open that URL in a browser.

### 3.2 API URL

The app calls the ColdFusion API. By default it uses:

```
http://localhost:8500/api/employees.cfm
```

If your CF server or path differs, create a `.env` in `frontend/`:

```
VITE_API_URL=http://YOUR_HOST:YOUR_PORT/api/employees.cfm
```

Restart `npm run dev` after changing `.env`.

### 3.3 Build for production

```bash
npm run build
```

Static files are in `frontend/dist/`. Serve them with any web server; ensure the API URL in `.env` (or the default) matches your production ColdFusion endpoint.

---

## 4. API endpoint

| Method | URL                      | Description        |
|--------|--------------------------|--------------------|
| GET    | `/api/employees.cfm`     | All employees (JSON). Optional `?search=` filters by first/last name (uses `cfqueryparam`). |
| OPTIONS| `/api/employees.cfm`     | CORS preflight     |

**Response (success, 200):** JSON array of employee objects:

```json
{
  "id": 1,
  "firstName": "Sarah",
  "lastName": "Johnson",
  "role": "Software Engineer"
}
```

**CORS:** `Access-Control-Allow-Origin: *`, `Access-Control-Allow-Methods: GET, OPTIONS`, `Access-Control-Allow-Headers: Content-Type`.

---

## 5. Module overview

- **`Employees.cfc`**  
  - `get()` runs `SELECT ID, FirstName, LastName, Role FROM Employees`, maps to JSON with camelCase fields (`id`, `firstName`, `lastName`, `role`).  
  - Uses `<cfqueryparam>` for all user-supplied search values (SQL injection protection).

- **`employees.cfm`**  
  - Sets CORS, handles OPTIONS, restricts to GET, calls `Employees.get()`, returns `application/json` with 200. On error, 500 and JSON `{ error, message }`.

- **`App.jsx`**  
  - `useEffect` fetches `/api/employees.cfm` on mount; `useState` for `employees`, `loading`, `error`, `search`.  
  - Search filters `employees` by `firstName`/`lastName` (case-insensitive, client-side).  
  - Renders: search input with stats, loading/error/empty states, responsive table (desktop), card grid (tablet/mobile).

---

## 6. Two-minute demo script

1. **Database (15 s)**  
   - Show `mysql/employees.sql` and run it (or `SELECT * FROM Employees`).

2. **ColdFusion API (30 s)**  
   - Show `api/Employees.cfc` and `api/employees.cfm`.  
   - Call `GET /api/employees.cfm` in browser or Postman; show JSON and CORS headers.

3. **React app (45 s)**  
   - `npm run dev`, open the app.  
   - Show list (table or cards), then type in the search box and show filtering by first/last name.  
   - Resize to show table vs cards.

4. **Wrap-up (30 s)**  
   - Quick recap: MySQL → ColdFusion (CFC + `.cfm`) → React (hooks, fetch, client-side search, responsive UI).

---

## Tech stack

- **MySQL** – `team_directory`, `Employees`
- **ColdFusion** – CFC, `cfquery`, `cfqueryparam` (for parameterized queries), JSON, CORS
- **React 18** – functional components, `useState`, `useEffect`
- **Vite** – build and dev server

---

## License

Use and adapt as needed for your environment.

