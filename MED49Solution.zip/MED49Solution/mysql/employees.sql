-- =============================================
-- Team Directory - MySQL Schema & Seed Data
-- =============================================
-- Run this script to create the database, table, and insert sample employees.
-- Usage: mysql -u root -p < employees.sql
-- =============================================

-- Create the database
CREATE DATABASE IF NOT EXISTS team_directory
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE team_directory;

-- Drop table if it exists (optional, for clean re-runs)
-- DROP TABLE IF EXISTS Employees;

-- Create the Employees table
CREATE TABLE IF NOT EXISTS Employees (
  ID INT AUTO_INCREMENT PRIMARY KEY,
  FirstName VARCHAR(100) NOT NULL,
  LastName VARCHAR(100) NOT NULL,
  Role VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert seed employee records
INSERT INTO Employees (FirstName, LastName, Role) VALUES
  ('Sarah', 'Johnson', 'Software Engineer'),
  ('Michael', 'Chen', 'Product Manager'),
  ('Emily', 'Davis', 'UX Designer'),
  ('James', 'Wilson', 'DevOps Engineer'),
  ('Olivia', 'Martinez', 'Data Analyst');

-- Verify insert
SELECT COUNT(*) AS total_employees FROM Employees;

