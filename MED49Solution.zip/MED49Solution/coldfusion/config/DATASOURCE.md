# ColdFusion Datasource (DSN) Configuration

## Create the `team_directory` DSN in ColdFusion Administrator

1. Open **ColdFusion Administrator** (e.g. `http://localhost:8500/CFIDE/administrator/`).
2. Go to **Data & Services** → **Data Sources**.
3. Click **Add New Data Source**.
4. Use these settings:

   | Setting      | Value           |
   |-------------|-----------------|
   | Data Source Name | `team_directory` |
   | Driver          | **MySQL** (or MySQL 5/8) |
   | Server          | `localhost` (or your MySQL host) |
   | Port            | `3306` |
   | Database        | `team_directory` |
   | Username        | your MySQL user |
   | Password        | your MySQL password |

5. Click **Submit**, then **Verify** to test the connection.

## Application.cfc

`Application.cfc` sets:

```cfml
application.dsn = "team_directory";
```

If you use a different DSN name, update `application.dsn` in `Application.cfc` → `onApplicationStart`.

## Using cfqueryparam

For any query that includes **user-supplied values** (e.g. search, filters, INSERT, UPDATE), use `<cfqueryparam>` to avoid SQL injection:

```cfml
<cfquery name="q" datasource="#application.dsn#">
  SELECT id, first_name, last_name, role
  FROM Employees
  WHERE last_name LIKE <cfqueryparam value="%#arguments.search#%" cfsqltype="cf_sql_varchar">
</cfquery>
```

The current `GET /api/employees` returns all rows and has no parameters, so no `cfqueryparam` is required for that query.

